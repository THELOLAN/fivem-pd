<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CronjobController extends Controller
{
    public function _run()
    {

    }
}
